package dma.pwr.lab2_adapters;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openSimpleList(View v){
        Intent i = new Intent();
        i.setClass(this, SimpleListAcitivity.class);
        startActivity(i);
    }
    public void openMultichoiceList(View v){
        Intent i = new Intent();
        i.setClass(this, MultichoiceListAcitivity.class);
        startActivityForResult(i, 0);
    }
    public void openGrid(View v){
        Intent i = new Intent();
        i.setClass(this, GridActivity.class);
        i.putExtra("ARG1", "Value1");
        i.putExtra("ARG2", "2");

        startActivity(i);
    }
    public void openCustomList(View v){
        Intent i = new Intent();
        i.setClass(this, CustomListActivity.class);
        i.putExtra("String value", "Value");
        startActivityForResult(i, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == 0){
            Toast.makeText(this, "Nothing Selected", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, data.getStringExtra("Result"), Toast.LENGTH_LONG).show();
        }
    }
}