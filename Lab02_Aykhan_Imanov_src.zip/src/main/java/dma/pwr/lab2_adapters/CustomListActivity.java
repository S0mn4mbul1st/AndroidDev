package dma.pwr.lab2_adapters;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import dma.pwr.lab2_adapters.custom.CustomAdapter;

public class CustomListActivity extends AppCompatActivity {

    String[] titles= {
            "1 Item 1",
            "2 Item 2",
            "3 Item 3",
            "4 Item 4",
            "5 Item 5",
            "6 Item 6",
            "7 Item 7",
            "8 Item 8",
            "9 Item 9"
    };
    String[] subtitles= {
            "1 1 1",
            "2 2 2",
            "3 3 3",
            "4 4 4",
            "5 5 5",
            "6 6 6",
            "7 7 7",
            "8 8 8",
            "9 9 9"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_list_acitivity);

        CustomAdapter a = new CustomAdapter(titles, subtitles, this);
        ListView lv = findViewById(R.id.custom_list_view);
        lv.setAdapter(a);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture){

    }
}