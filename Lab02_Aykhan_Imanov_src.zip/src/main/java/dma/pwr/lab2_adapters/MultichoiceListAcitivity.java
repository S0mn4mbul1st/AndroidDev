package dma.pwr.lab2_adapters;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MultichoiceListAcitivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    String[] items= {
            "1 Item 1",
            "2 Item 2",
            "3 Item 3",
            "4 Item 4",
            "5 Item 5",
            "6 Item 6",
            "7 Item 7",
            "8 Item 8",
            "9 Item 9"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multichoice_list_acitivity);
        setResult(0);

        ArrayAdapter<String> arr = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice);
        arr.addAll(items);

        ListView lv = findViewById(R.id.multichoice_list_view);
        lv.setAdapter(arr);
        lv.setOnItemClickListener(this);
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l){
        String info = "Checked: ";
        SparseBooleanArray checked = (((ListView)findViewById(R.id.multichoice_list_view)).getCheckedItemPositions());

        for(int j=0; j<checked.size(); ++j){

            if(checked.get(j)) {

                info = info + "," + items[j];
            }
        }
        getIntent().putExtra("RESULTS", info);

        setResult(1, getIntent());

        Toast.makeText(this, info, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture){

    }
}