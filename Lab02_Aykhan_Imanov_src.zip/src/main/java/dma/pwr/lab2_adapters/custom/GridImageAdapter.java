package dma.pwr.lab2_adapters.custom;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import dma.pwr.lab2_adapters.R;

public class GridImageAdapter extends BaseAdapter {
    private Context ctx;

    public Integer[] images = {
            R.drawable.coin1, R.drawable.coin1, R.drawable.coin1,
            R.drawable.coin2, R.drawable.coin2, R.drawable.coin2,
            R.drawable.coin3, R.drawable.coin3, R.drawable.coin3
    };

    public GridImageAdapter(Context c){
        ctx = c;
    }

    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        ImageView v;
        if(convertView == null){
            v = new ImageView(ctx);
            v.setLayoutParams(new ViewGroup.LayoutParams(200, 200));
            v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            v = (ImageView) convertView;
        }
        v.setImageResource(images[i]);
        return v;
    }
}
